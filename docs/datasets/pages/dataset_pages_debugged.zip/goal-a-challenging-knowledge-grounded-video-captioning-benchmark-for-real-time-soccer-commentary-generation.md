---
title: "GOAL: A Challenging Knowledge-grounded Video Captioning Benchmark for Real-time Soccer Commentary Generation"
subtitle: "GOAL"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:257766604){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:257766604){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/goal-a-challenging-knowledge-grounded-video-captioning-benchmark-for-real-time-soccer-commentary-generation.bib){ .btn .btn-warning download }