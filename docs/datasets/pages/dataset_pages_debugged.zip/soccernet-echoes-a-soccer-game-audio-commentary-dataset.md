---
title: "SoccerNet-Echoes: A Soccer Game Audio Commentary Dataset"
subtitle: "SoccerNet-Echoes"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:269757092){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:269757092){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/soccernet-echoes-a-soccer-game-audio-commentary-dataset.bib){ .btn .btn-warning download }