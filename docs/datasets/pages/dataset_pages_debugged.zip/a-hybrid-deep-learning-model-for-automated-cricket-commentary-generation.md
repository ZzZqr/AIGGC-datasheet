---
title: "A Hybrid Deep Learning Model for Automated Cricket Commentary Generation"
subtitle: "Flickr+Cricket"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/ICCCMLA63077.2024.10871604){target="_blank"}

[Download Paper](https://doi.org/10.1109/ICCCMLA63077.2024.10871604){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/a-hybrid-deep-learning-model-for-automated-cricket-commentary-generation.bib){ .btn .btn-warning download }