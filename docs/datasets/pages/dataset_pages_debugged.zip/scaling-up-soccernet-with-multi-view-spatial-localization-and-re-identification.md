---
title: "Scaling up SoccerNet with Multi-view Spatial Localization and Re-identification"
subtitle: "SoccerNet-v3"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:249894209){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:249894209){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/scaling-up-soccernet-with-multi-view-spatial-localization-and-re-identification.bib){ .btn .btn-warning download }