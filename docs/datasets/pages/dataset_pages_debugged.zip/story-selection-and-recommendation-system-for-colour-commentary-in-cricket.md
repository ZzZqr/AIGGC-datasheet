---
title: "STORY SELECTION AND RECOMMENDATION SYSTEM FOR COLOUR COMMENTARY IN CRICKET"
subtitle: "Cricket Story Set"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:212473004){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:212473004){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/story-selection-and-recommendation-system-for-colour-commentary-in-cricket.bib){ .btn .btn-warning download }