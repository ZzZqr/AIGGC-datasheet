---
title: "Learning a game commentary generator with grounded move expressions"
subtitle: "Shogi Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/CIG.2015.7317930){target="_blank"}

[Download Paper](https://doi.org/10.1109/CIG.2015.7317930){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/learning-a-game-commentary-generator-with-grounded-move-expressions.bib){ .btn .btn-warning download }