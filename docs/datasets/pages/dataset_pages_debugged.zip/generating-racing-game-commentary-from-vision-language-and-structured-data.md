---
title: "Generating Racing Game Commentary from Vision, Language, and Structured Data"
subtitle: "Racing Commentary Dataset1"
tags: ["Unknown", "Unknown"]
---

We propose the task of automatically generating commentaries for races in a motor racing game, from vision, structured numerical, and textual data. Commentaries provide information to support spectators in understanding events in races. Commentary generation models need to interpret the race situation and generate the correct content at the right moment. We divide the task into two subtasks: utterance timing identification and utterance generation. Because existing datasets do not have such alignments of data in multiple modalities, this setting has not been explored in depth. In this study, we introduce a new large-scale dataset that contains aligned video data, structured numerical data, and transcribed commentaries that consist of 129,226 utterances in 1,389 races in a game. Our analysis reveals that the characteristics of commentaries change over time or from viewpoints. Our experiments on the subtasks show that it is still challenging for a state-of-the-art vision encoder to capture useful information from videos to generate accurate commentaries. We make the dataset and baseline implementation publicly available for further research.

**Source**: [DOI Link](https://doi.org/10.18653/v1/2021.inlg-1.11){target="_blank"}

[Download Paper](https://doi.org/10.18653/v1/2021.inlg-1.11){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/generating-racing-game-commentary-from-vision-language-and-structured-data.bib){ .btn .btn-warning download }