---
title: "Training a Multilingual Sportscaster: Using Perceptual Context to Learn Language"
subtitle: "Robocup Sportscasts2"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:6678765){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:6678765){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/training-a-multilingual-sportscaster-using-perceptual-context-to-learn-language.bib){ .btn .btn-warning download }