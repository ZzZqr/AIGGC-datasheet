---
title: "Automated Story Selection for Color Commentary in Sports"
subtitle: "Baseball Story Set2"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/TCIAIG.2013.2275199){target="_blank"}

[Download Paper](https://doi.org/10.1109/TCIAIG.2013.2275199){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/automated-story-selection-for-color-commentary-in-sports.bib){ .btn .btn-warning download }