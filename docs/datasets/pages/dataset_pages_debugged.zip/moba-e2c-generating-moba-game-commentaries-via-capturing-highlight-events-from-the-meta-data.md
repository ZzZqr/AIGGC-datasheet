---
title: "{MOBA}-{E}2{C}: Generating {MOBA} Game Commentaries via Capturing Highlight Events from the Meta-Data"
subtitle: "Dota2-Commentary"
tags: ["Unknown", "Unknown"]
---

MOBA (Multiplayer Online Battle Arena) games such as Dota2 are currently one of the most popular e-sports gaming genres. Following professional commentaries is a great way to understand and enjoy a MOBA game. However, massive game competitions lack commentaries because of the shortage of professional human commentators. As an alternative, employing machine commentators that can work at any time and place is a feasible solution. Considering the challenges in modeling MOBA games, we propose a data-driven MOBA commentary generation framework, MOBA-E2C, allowing a model to generate commentaries based on the game meta-data. Subsequently, to alleviate the burden of collecting supervised data, we propose a MOBA-FuseGPT generator to generate MOBA game commentaries by fusing the power of a rule-based generator and a generative GPT generator. Finally, in the experiments, we take a popular MOBA game Dota2 as our case and construct a Chinese Dota2 commentary generation dataset Dota2-Commentary. Experimental results demonstrate the superior performance of our approach. To the best of our knowledge, this work is the first Dota2 machine commentator and Dota2-Commentary is the first dataset.

**Source**: [DOI Link](https://doi.org/10.18653/v1/2022.findings-emnlp.333){target="_blank"}

[Download Paper](https://doi.org/10.18653/v1/2022.findings-emnlp.333){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/moba-e2c-generating-moba-game-commentaries-via-capturing-highlight-events-from-the-meta-data.bib){ .btn .btn-warning download }