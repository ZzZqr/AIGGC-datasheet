---
title: "Annotating Modality Expressions and Event Factuality for a {J}apanese Chess Commentary Corpus"
subtitle: "Shogi Annotated Corpus1"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://aclanthology.org/L18-1393/){target="_blank"}

[Download Paper](https://aclanthology.org/L18-1393/){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/annotating-modality-expressions-and-event-factuality-for-a-japanese-chess-commentary-corpus.bib){ .btn .btn-warning download }