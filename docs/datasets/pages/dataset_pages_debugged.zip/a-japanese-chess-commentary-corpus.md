---
title: "A {J}apanese Chess Commentary Corpus"
subtitle: "Shogi Commentary Corpus"
tags: ["Unknown", "Unknown"]
---

In recent years there has been a surge of interest in the natural language prosessing related to the real world, such as symbol grounding, language generation, and nonlinguistic data search by natural language queries. In order to concentrate on language ambiguities, we propose to use a well-defined {\textquotedblleft}real world,{\textquotedblright} that is game states. We built a corpus consisting of pairs of sentences and a game state. The game we focus on is shogi (Japanese chess). We collected 742,286 commentary sentences in Japanese. They are spontaneously generated contrary to natural language annotations in many image datasets provided by human workers on Amazon Mechanical Turk. We defined domain specific named entities and we segmented 2,508 sentences into words manually and annotated each word with a named entity tag. We describe a detailed definition of named entities and show some statistics of our game commentary corpus. We also show the results of the experiments of word segmentation and named entity recognition. The accuracies are as high as those on general domain texts indicating that we are ready to tackle various new problems related to the real world.

**Source**: [DOI Link](https://aclanthology.org/L16-1225/){target="_blank"}

[Download Paper](https://aclanthology.org/L16-1225/){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/a-japanese-chess-commentary-corpus.bib){ .btn .btn-warning download }