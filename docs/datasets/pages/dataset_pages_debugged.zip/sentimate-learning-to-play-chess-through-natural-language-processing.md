---
title: "SentiMATE: Learning to play Chess through Natural Language Processing"
subtitle: "SentiMATE Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:197935466){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:197935466){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/sentimate-learning-to-play-chess-through-natural-language-processing.bib){ .btn .btn-warning download }