---
title: "GameFlow: Narrative Visualization of NBA Basketball Games"
subtitle: "GameFlow Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/TMM.2016.2614221){target="_blank"}

[Download Paper](https://doi.org/10.1109/TMM.2016.2614221){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/gameflow-narrative-visualization-of-nba-basketball-games.bib){ .btn .btn-warning download }