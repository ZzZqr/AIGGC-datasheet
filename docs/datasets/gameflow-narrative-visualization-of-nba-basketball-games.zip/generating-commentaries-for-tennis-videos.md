---
title: "Generating commentaries for tennis videos"
subtitle: "Tennis Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/ICPR.2016.7900036){target="_blank"}

[Download Paper](https://doi.org/10.1109/ICPR.2016.7900036){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/generating-commentaries-for-tennis-videos.bib){ .btn .btn-warning download }