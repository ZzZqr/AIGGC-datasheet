---
title: "CS-lol: a Dataset of Viewer Comment with Scene in E-sports Live-streaming"
subtitle: "CS-lol"
tags: ["Unknown", "Unknown"]
---

Billions of live-streaming viewers share their opinions on scenes they are watching in real-time and interact with the event, commentators as well as other viewers via text comments. Thus, there is necessary to explore viewers’ comments with scenes in E-sport live-streaming events. In this paper, we developed CS-lol, a new large-scale dataset containing comments from viewers paired with descriptions of game scenes in E-sports live-streaming. Moreover, we propose a task, namely viewer comment retrieval, to retrieve the viewer comments for the scene of the live-streaming event. Results on a series of baseline retrieval methods derived from typical IR evaluation methods show our task as a challenging task. Finally, we release CS-lol and baseline implementation to the research community as a resource.

**Source**: [DOI Link](https://doi.org/10.1145/3576840.3578334){target="_blank"}

[Download Paper](https://doi.org/10.1145/3576840.3578334){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/cs-lol-a-dataset-of-viewer-comment-with-scene-in-e-sports-live-streaming.bib){ .btn .btn-warning download }