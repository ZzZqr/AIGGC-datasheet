---
title: "Detection and labeling of bad moves for coaching go"
subtitle: "Move Quality Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/CIG.2016.7860441){target="_blank"}

[Download Paper](https://doi.org/10.1109/CIG.2016.7860441){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/detection-and-labeling-of-bad-moves-for-coaching-go.bib){ .btn .btn-warning download }