---
title: "Extraction of Strong and Weak Regions of Cricket Batsman through Text-Commentary Analysis"
subtitle: "Cricinfo Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/INMIC50486.2020.9318089){target="_blank"}

[Download Paper](https://doi.org/10.1109/INMIC50486.2020.9318089){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/extraction-of-strong-and-weak-regions-of-cricket-batsman-through-text-commentary-analysis.bib){ .btn .btn-warning download }