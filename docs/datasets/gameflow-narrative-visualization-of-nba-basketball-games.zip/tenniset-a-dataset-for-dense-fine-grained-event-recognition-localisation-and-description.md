---
title: "TenniSet: A Dataset for Dense Fine-Grained Event Recognition, Localisation and Description"
subtitle: "TenniSet"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/DICTA.2017.8227494){target="_blank"}

[Download Paper](https://doi.org/10.1109/DICTA.2017.8227494){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/tenniset-a-dataset-for-dense-fine-grained-event-recognition-localisation-and-description.bib){ .btn .btn-warning download }