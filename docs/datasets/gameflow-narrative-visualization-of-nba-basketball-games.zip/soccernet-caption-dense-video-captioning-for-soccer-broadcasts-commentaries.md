---
title: "SoccerNet-Caption: Dense Video Captioning for Soccer Broadcasts Commentaries"
subtitle: "SoccerNet-Caption"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:258049025){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:258049025){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/soccernet-caption-dense-video-captioning-for-soccer-broadcasts-commentaries.bib){ .btn .btn-warning download }