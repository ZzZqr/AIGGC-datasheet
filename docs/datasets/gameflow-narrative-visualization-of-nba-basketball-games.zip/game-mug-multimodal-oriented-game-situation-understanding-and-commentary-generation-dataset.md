---
title: "Game-MUG: Multimodal Oriented Game Situation Understanding and Commentary Generation Dataset"
subtitle: "Game-MUg"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:269456978){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:269456978){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/game-mug-multimodal-oriented-game-situation-understanding-and-commentary-generation-dataset.bib){ .btn .btn-warning download }