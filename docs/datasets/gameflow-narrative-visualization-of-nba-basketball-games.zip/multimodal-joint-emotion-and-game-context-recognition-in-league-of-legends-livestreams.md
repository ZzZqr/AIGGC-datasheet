---
title: "Multimodal Joint Emotion and Game Context Recognition in League of Legends Livestreams"
subtitle: "Multimodal LoL Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/CIG.2019.8848060){target="_blank"}

[Download Paper](https://doi.org/10.1109/CIG.2019.8848060){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/multimodal-joint-emotion-and-game-context-recognition-in-league-of-legends-livestreams.bib){ .btn .btn-warning download }