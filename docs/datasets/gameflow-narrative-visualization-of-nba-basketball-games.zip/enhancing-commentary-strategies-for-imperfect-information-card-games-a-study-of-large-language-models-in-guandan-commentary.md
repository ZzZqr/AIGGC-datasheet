---
title: "Enhancing Commentary Strategies for Imperfect Information Card Games: A Study of Large Language Models in Guandan Commentary"
subtitle: "GuanDan Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:270737995){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:270737995){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/enhancing-commentary-strategies-for-imperfect-information-card-games-a-study-of-large-language-models-in-guandan-commentary.bib){ .btn .btn-warning download }