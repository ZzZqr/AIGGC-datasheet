---
title: "Understanding Game-Playing Agents with Natural Language Annotations"
subtitle: "Go Annotated Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:248218465){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:248218465){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/understanding-game-playing-agents-with-natural-language-annotations.bib){ .btn .btn-warning download }