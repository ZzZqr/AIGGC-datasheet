---
title: "Outcome Classification in Cricket Using Deep Learning"
subtitle: "Ball-by-Ball Classification"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/CCEM48484.2019.00012){target="_blank"}

[Download Paper](https://doi.org/10.1109/CCEM48484.2019.00012){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/outcome-classification-in-cricket-using-deep-learning.bib){ .btn .btn-warning download }