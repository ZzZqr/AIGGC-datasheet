---
title: "Generating Live Soccer-Match Commentary from Play Data"
subtitle: "OptaSports"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:57854642){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:57854642){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/generating-live-soccer-match-commentary-from-play-data.bib){ .btn .btn-warning download }