---
title: "Learning to Generate Move-by-Move Commentary for Chess Games from Large-Scale Social Forum Data"
subtitle: "Chess Benchmark"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.18653/v1/P18-1154){target="_blank"}

[Download Paper](https://doi.org/10.18653/v1/P18-1154){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/learning-to-generate-move-by-move-commentary-for-chess-games-from-large-scale-social-forum-data.bib){ .btn .btn-warning download }