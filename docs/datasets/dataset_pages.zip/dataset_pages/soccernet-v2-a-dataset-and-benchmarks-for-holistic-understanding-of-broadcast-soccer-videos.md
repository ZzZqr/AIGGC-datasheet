---
title: "SoccerNet-v2: A Dataset and Benchmarks for Holistic Understanding of Broadcast Soccer Videos"
subtitle: "SoccerNet-v2"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/CVPRW53098.2021.00508){target="_blank"}

[Download Paper](https://doi.org/10.1109/CVPRW53098.2021.00508){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/soccernet-v2-a-dataset-and-benchmarks-for-holistic-understanding-of-broadcast-soccer-videos.bib){ .btn .btn-warning download }