---
title: "From eSports Data to Game Commentary: Datasets, Models, and Evaluation Metrics"
subtitle: "LoL19"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:235327865){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:235327865){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/from-esports-data-to-game-commentary-datasets-models-and-evaluation-metrics.bib){ .btn .btn-warning download }