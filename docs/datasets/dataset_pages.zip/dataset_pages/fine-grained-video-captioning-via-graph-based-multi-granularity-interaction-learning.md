---
title: "Fine-Grained Video Captioning via Graph-based Multi-Granularity Interaction Learning"
subtitle: "SVN"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/TPAMI.2019.2946823){target="_blank"}

[Download Paper](https://doi.org/10.1109/TPAMI.2019.2946823){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/fine-grained-video-captioning-via-graph-based-multi-granularity-interaction-learning.bib){ .btn .btn-warning download }