---
title: "Learning to sportscast: a test of grounded language acquisition"
subtitle: "Robocup Sportscasts1"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:2488088){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:2488088){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/learning-to-sportscast-a-test-of-grounded-language-acquisition.bib){ .btn .btn-warning download }