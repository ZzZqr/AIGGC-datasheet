---
title: "Ball-by-Ball Cricket Commentary Generation using Stateful Sequence-to-Sequence Model"
subtitle: "Cricket Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/ComTech52583.2021.9616676){target="_blank"}

[Download Paper](https://doi.org/10.1109/ComTech52583.2021.9616676){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/ball-by-ball-cricket-commentary-generation-using-stateful-sequence-to-sequence-model.bib){ .btn .btn-warning download }