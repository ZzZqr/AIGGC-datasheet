---
title: "{M}atch{T}ime: Towards Automatic Soccer Game Commentary Generation"
subtitle: "MatchTime"
tags: ["Unknown", "Unknown"]
---

Soccer is a globally popular sport with a vast audience, in this paper, we consider constructing an automatic soccer game commentary model to improve the audiences' viewing experience. In general, we make the following contributions: *First*, observing the prevalent video-text misalignment in existing datasets, we manually annotate timestamps for 49 matches, establishing a more robust benchmark for soccer game commentary generation, termed as *SN-Caption-test-align*; *Second*, we propose a multi-modal temporal alignment pipeline to automatically correct and filter the existing dataset at scale, creating a higher-quality soccer game commentary dataset for training, denoted as *MatchTime*; *Third*, based on our curated dataset, we train an automatic commentary generation model, named **MatchVoice**. Extensive experiments and ablation studies have demonstrated the effectiveness of our alignment pipeline, and training model on the curated datasets achieves state-of-the-art performance for commentary generation, showcasing that better alignment can lead to significant performance improvements in downstream tasks.

**Source**: [DOI Link](https://doi.org/10.18653/v1/2024.emnlp-main.99){target="_blank"}

[Download Paper](https://doi.org/10.18653/v1/2024.emnlp-main.99){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/matchtime-towards-automatic-soccer-game-commentary-generation.bib){ .btn .btn-warning download }