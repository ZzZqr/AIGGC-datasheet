---
title: "SoccerNet: A Scalable Dataset for Action Spotting in Soccer Videos"
subtitle: "SoccerNet"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/cvprw.2018.00223){target="_blank"}

[Download Paper](https://doi.org/10.1109/cvprw.2018.00223){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/soccernet-a-scalable-dataset-for-action-spotting-in-soccer-videos.bib){ .btn .btn-warning download }