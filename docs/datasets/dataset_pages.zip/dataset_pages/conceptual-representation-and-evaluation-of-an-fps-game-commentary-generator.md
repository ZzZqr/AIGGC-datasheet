---
title: "Conceptual Representation and Evaluation of an FPS Game Commentary Generator"
subtitle: "FPS Commentary Dataset"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:249929159){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:249929159){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/conceptual-representation-and-evaluation-of-an-fps-game-commentary-generator.bib){ .btn .btn-warning download }