---
title: "Automated cricket commentary generation using deep learning"
subtitle: "Commentary-Frame"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://api.semanticscholar.org/CorpusID:268587932){target="_blank"}

[Download Paper](https://api.semanticscholar.org/CorpusID:268587932){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/automated-cricket-commentary-generation-using-deep-learning.bib){ .btn .btn-warning download }