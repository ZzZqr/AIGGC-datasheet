---
title: "LoL-V2T: Large-Scale Esports Video Description Dataset"
subtitle: "LoL-V2T"
tags: ["Unknown", "Unknown"]
---

Abstract not available.

**Source**: [DOI Link](https://doi.org/10.1109/CVPRW53098.2021.00513){target="_blank"}

[Download Paper](https://doi.org/10.1109/CVPRW53098.2021.00513){ .btn .btn-primary target="_blank" }
[Download BibTeX](bib/lol-v2t-large-scale-esports-video-description-dataset.bib){ .btn .btn-warning download }